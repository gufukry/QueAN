﻿# QueAN 功能审计报告

> 审计时间：2026-09-03 ｜ 基线：PCL2 正式版 2.12.x + 社区版 CE
> 状态档位：✅ 已实装且可用 ｜ 🟡 部分实现 ｜ 🔴 仅有入口 ｜ ⛔ 入口损坏 ｜ ⚪ 完全缺失

## 〇、项目识别结论

| 项 | 结论 |
|---|---|
| 技术栈 | Electron 33 + Vue 3.5（`<script setup>`）+ TypeScript 5.6；全局状态为 `reactive` 单例（store.ts）；唯一运行时依赖 adm-zip |
| 构建 | `electron-vite build` 三目标打包；Windows 分发走 `electron-builder --win portable`；macOS 走自研 `scripts/pack-mac.mjs`（zip 层重写 .app、手工拼 icns、注入 asar，Windows 无 symlink 权限下可用） |
| 模块划分 | 主进程 `src/main/core/`：accounts / versions / download / java / launch / loaders / modpacks / community / skins / settings / paths；`ipc.ts` 集中注册 34 个 invoke 通道 + 5 个事件通道；契约集中在 `src/shared/types.ts` |
| 数据流 | 请求-响应 `ipcRenderer.invoke`；长任务 invoke 仅受理，进度 `event:progress`、结果 `event:installDone`/`event:launchState`、日志 `event:launchLog`、登录 `event:msLoginDone` 推送 |
| 持久化 | userData：settings.json / accounts.json / skins.json+skins/*.png；游戏数据默认 `%AppData%\.quean`；localStorage 存最近游玩/上次版本/Banner 对齐 |

**版本标识不一致**：package.json 为 0.4.1，但 UI 与启动参数硬编码 0.1.0（App.vue:22、HomeView.vue:518、launch.ts:284）。

## 一、功能盘点总表

### 启动链路（P0）

| 模块 | 功能 | 入口位置 | 状态 | 问题描述 | 对标 PCL |
|---|---|---|---|---|---|
| 账号 | 离线登录 | AccountsView.vue:29-46 → accounts.ts:104 | ✅ | 3-16 位校验，MD5 OfflinePlayer UUID 与官方一致 | 离线模式 |
| 账号 | 微软正版登录 | AccountsView.vue:55-104 → accounts.ts:292 | ✅ | device code 全链路（XBL→XSTS→MC→拥有权），refresh_token 临期自动续期 | 微软 OAuth |
| 账号 | 第三方外置登录 | — | ⚪ | 无入口，grep 无 authlib 相关代码 | authlib-injector（LittleSkin 等） |
| 账号 | 多账号快速切换 | HomeView.vue:453 | 🟡 | 只能跳账号页点选，无首页下拉速切 | 账号下拉速切 |
| 启动 | 参数拼接/classpath/natives | launch.ts 全文 | ✅ | inheritsFrom 链合并、rules 官方语义、变量全表替换、natives 解压+classpath 双保险 |
| 启动 | 启动自愈 | launch.ts:139-160 | ✅ | 链 json/client jar/依赖库缺失自动补下 |
| 启动 | 启动后关闭启动器 | SettingsView.vue:312 | ✅ | 已于 0.4.2 实装（ipc.ts gameLaunch onState：running 后 1.5s 关窗；验证：开启开关后启动游戏，启动器自动关闭） | 启动后隐藏/关闭 |
| 启动 | 日志实时查看 | HomeView.vue:344 | ✅ | 实时滚动 + 落盘 quean-logs/latest.log |
| 启动 | 日志导出 | — | ⚪ | 无导出/打开日志目录入口 | 日志导出 |

### 下载与版本管理（P1）

| 模块 | 功能 | 入口位置 | 状态 | 问题描述 | 对标 PCL |
|---|---|---|---|---|---|
| 版本 | MC 版本列表 | GameView.vue:218 → versions.ts:135 | ✅ | 官方+BMCLAPI 镜像可切，1h 缓存+过期回退 | 双源下载 |
| 版本 | 本体自动下载 | versions.ts:280-360 | ✅ | 并发 8、sha1 校验、镜像失败自动切换重试 3 次 | — |
| 版本 | 断点续传 | download.ts:71 | 🟡 | .part 临时文件+整包重试，无 Range 续传 | 断点续传 |
| 加载器 | Forge/NeoForge | loaders.ts:225-280 | ✅ | installer CLI 静默安装（已实测成功）；launcher_profiles.json 自动补 | — |
| 加载器 | Fabric/Quilt | loaders.ts:193-223 | ✅ | profile 直写 + maven 坐标库下载 | — |
| 加载器 | OptiFine | — | ⚪ | 无入口 | OptiFine 安装与组合 |
| 加载器 | 组合安装（Fabric+OptiFine 等） | — | ⚪ | 无 | 组合兼容处理 |
| 加载器 | Fabric API 联动 | GameView.vue:357 → loaders.ts:305 | ✅ | 已于 0.4.2 修复文件编码（验证：安装 Fabric 版本时勾选 Fabric API，进度文案正常中文显示） | Fabric API 推荐 |
| Java | 扫描/匹配/自动下载 | java.ts 全文 + SettingsView 开关 | ✅ | 多路径扫描、按版本匹配（含 26.x 新命名）、Adoptium 下载解压、开关默认开 | Java 自动管理 |
| 版本 | 多版本共存 | versions/ 目录隔离 | ✅ | — | — |
| 版本 | 版本隔离开关 | GameView 已安装区每行 | ✅ | 0.5.0 实装：开关+共享数据复制迁移+关闭回共享；整合包实例强制隔离（验证：已安装区切换开关，versions/<id> 出现 saves/mods 副本） | 版本隔离 |
| 版本 | 版本设置（内存/JVM/分辨率/Java 路径） | SettingsView 全局 | 🟡 | 只有全局设置，无**单版本独立设置** | 版本独立设置 |
| 版本 | 重复安装/加装加载器 | GameView.vue:281 | ✅ | 已安装可再安装（文件校验跳过） | — |

### MOD 与整合包（P2）

| 模块 | 功能 | 入口位置 | 状态 | 问题描述 | 对标 PCL |
|---|---|---|---|---|---|
| MOD | 本地列表/删除 | FileManager.vue | 🟡 | 裸文件名/大小/日期；删除无确认 | — |
| MOD | 启用/禁用 | — | ⚪ | 无 .disabled 切换 | MOD 开关 |
| MOD | MOD 信息识别 | — | ⚪ | 不解析 jar（fabric.mod.json/mods.toml），无图标/描述 | MOD 详情 |
| MOD | 在线搜索下载 | CommunityView.vue | ✅ | Modrinth 官方+MCIM / CurseForge MCIM 免 key，双源并发合并 | 双源搜索 |
| MOD | 更新检测 | — | ⚪ | 无 | 更新角标 |
| MOD | 前置依赖/冲突提示 | — | ⚪ | 无 | 依赖提示 |
| 整合包 | 拖入导入（mrpack/CF zip） | App.vue:110-234 → modpacks.ts | ✅ | 三格式探测、命名二选、实例隔离、安全过滤 | 拖入安装 |
| 整合包 | 解压即玩全量包 | modpacks.ts fullpack | ✅ | versions 注册+实例归位+无用文件清理（exe/日志/__MACOSX 等） | — |
| 整合包 | 导出 | — | ⚪ | 无入口 | 导出分享 |
| 整合包 | 在线搜索下载 | CommunityView 类型=整合包 | ✅ | 下载 mrpack 自动进入安装 | — |
| 下载 | 下载进度统一反馈 | — | 🟡 | 全局单 progress 对象按 stage 回跳；整合包/社区安装全程无进度条，仅首末 toast | 下载中心 |

### 账号外观与资源（P3）

| 模块 | 功能 | 入口位置 | 状态 | 问题描述 | 对标 PCL |
|---|---|---|---|---|---|
| 皮肤 | 查看/上传/历史/换回 | SkinsView.vue → skins.ts | ✅ | 官方 API，64×64 校验，历史 30 条；0.5.0 升级 **3D 查看器**（Three.js：走路动画+拖拽旋转，slim/classic 双模型） | 皮肤管理 |
| 皮肤 | 披风切换/卸下 | SkinsView.vue:368 | ✅ | PUT/DELETE 真实调用，外观渲染 | — |
| 皮肤 | 离线自定义皮肤 | — | ⚪ | 离线账号仅引导（无外置登录/skinme 支持） | 离线皮肤 |
| 资源 | 资源包/光影包本地管理 | Packs/Shaders FileManager | ✅ | 列表/删除/打开目录 | — |
| 资源 | 资源包/光影在线下载 | CommunityView 对应类型 | ✅ | 落对应版本目录 | — |
| 存档 | 存档下载与管理 | — | ⚪ | 无任何 saves 入口 | 存档管理 |
| 头像 | 账户卡方块头像 | Avatar.vue | ✅ | 微软=皮肤头渲染/离线=minotar | — |

### 体验与工具（P4）

| 模块 | 功能 | 入口位置 | 状态 | 问题描述 | 对标 PCL |
|---|---|---|---|---|---|
| 工具 | 崩溃分析 | — | ⚪ | 无 crash-report 读取与建议 | 崩溃分析器 |
| 服务器 | 服务器页 | ServersView.vue | ✅ | 已于 0.4.2 实装：列表增删、SLP ping（MOTD/人数/延迟/版本）、一键进服、删除二次确认（验证：添加 mc.hypixel.net 等公共服看状态） | 服务器管理 |
| 个性化 | 三主题+自定义+点选编辑+主题码 | Settings/EditPanel | ✅ | 含布局滑块与分享码 | 主题 |
| 个性化 | 背景音乐/主页模块自定义 | — | ⚪ | 无 | 背景音乐/主页定制 |
| 启动器 | 自动检查更新 | — | ⚪ | 无（版本号还硬编码 0.1.0） | 更新通道 |
| 通知 | 通知中心 | App.vue:512 铃铛 | 🔴 | toast 占位 | 通知中心 |
| 窗口 | 最大化按钮 | — | ⚪ | IPC 已注册但 UI 无按钮 | — |
| 杂项 | 顶栏搜索全局生效 | App.vue:488 | 🟡 | 仅游戏页消费；模组/资源包/社区页无效 | 全局搜索 |
| 杂项 | 快速操作·导入整合包 | HomeView.vue:223 | 🔴 | toast「敬请期待」遗留占位（顶栏导入已实装，矛盾） | — |
| 杂项 | 删除二次确认 | 多处删除 | 🟡 | 版本/文件删除均无确认、不校验运行中 | — |
| 杂项 | 下载速度显示 | types.ts ProgressEvent.speed | ⚪ | 字段存在但主进程从未发送 | 速度显示 |
| 杂项 | 离线模式开关 | HomeView.vue:469 | 🔴 | disabled 展示型开关，无逻辑 | — |
| 杂项 | 数据包落地目录 | community.ts:303 | 🟡 | 落 gameDir/datapacks，MC 不加载，需投 saves/<世界> 或提示 | — |
| 杂项 | 整合包实例 mcVersion 语义 | versions.ts:401 | 🟡 | 记为加载器 profile id，污染「已安装」判定与社区页版本筛选 | — |
| 杂项 | 整合包下载镜像 | modpacks.ts:738 | 🟡 | 硬编码 official，镜像设置不生效 | — |

## 二、横切 Bug 清单（建议阶段二最先修）

| # | 位置 | 问题 | 严重度 | 状态 |
|---|---|---|---|---|
| 1 | loaders.ts:282-353 | Fabric API 文案编码损坏（用户可见乱码） | 高 ⛔ | ✅ 已修（0.4.2） |
| 2 | SettingsView × launch.ts | closeAfterLaunch 死设置 | 高 ⛔ | ✅ 已修（0.4.2） |
| 3 | App.vue / HomeView.vue / launch.ts | 版本号硬编码 0.1.0 | 中 | ✅ 已修（vite define 注入） |
| 4 | HomeView.vue | 快速操作导入整合包占位 | 中 | ✅ 已修（接全局导入弹窗） |
| 5 | versions.ts | 整合包实例 mcVersion 语义污染 | 中 | ✅ 已修（链底解析） |
| 6 | community.ts | datapack 落盘目录不被 MC 加载 | 中 | ✅ 已修（唯一存档直投+提示） |
| 7 | store.progress 单例 | 多任务安装进度互相覆盖/回跳 | 中 | ✅ 已修（整体进度单调化+速度显示） |
| 8 | modpacks.ts | 整合包下载不走镜像 | 低 | ✅ 已修 |
| 9 | 多处删除 | 无二次确认 | 低 | ✅ 全部加确认框（ConfirmModal） |
| 10 | AccountsView 微软登录按钮 | 无 loading 态 | 低 | ✅ 已修 |

## 三、总体结论（更新）

## 三、总体结论

核心链路（版本安装、四种加载器、Fabric API、Java 自动管理、离线/微软账号与续期、皮肤披风、双源社区下载、三格式整合包导入+全量包、实例隔离启动、点选式个性化与主题码、开屏动画）均已真实闭环，完成度较高。

主要缺口：**服务器页（纯占位）、启动后关闭（死设置）、loaders.ts 乱码**三处硬伤；**外置登录、OptiFine、MOD 信息管理（识别/启停/更新/依赖）、整合包导出、存档管理、崩溃分析、版本隔离与单版本设置、启动器自更新**等对 PCL 的大片空白域。

---

> 阶段一审计到此为止，等待确认后进入阶段二（P0→P4 逐模块实装）。
> 建议阶段二开始前先 `git init` 建立版本库，以便按模块 commit/回滚。
